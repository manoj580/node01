var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var session = require('express-session');
var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var { v4 : uuidv4} = require('uuid');
var app = express();
app.use(session({          //  created a session and given unique id to it.   
  genid: function(req) {
    return uuidv4(); // use UUIDs for session IDs
  },
  secret: 'keyboard cat',   //random unique string value used to authenticate a session
  resave: false,               //sesion to be stored back in session store
  saveUninitialized: true,           //any uninitialized session is sent to store
  cookie: { maxAge:30000,username:'Ankam Manoj' } //cookie will be able to modify using js
}))
// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});
app.use(function(req, res, next){
  
  next();
});
module.exports = app;
