var $ = require('jquery');
var nav = require('navigator');
var express = require('express');
var alert = require('alert');
var router = express.Router();
const nodemailer = require('nodemailer');
const bcrypt = require("bcryptjs");
const { ObjectId, MongoMissingCredentialsError, GridFSBucketReadStream } = require('mongodb');
const SMTPConnection = require('nodemailer/lib/smtp-connection');
const session = require('express-session');
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/myresdb";
const bodyParser = require('body-parser');
const { body, check, validationResult } = require('express-validator');
const { render } = require('ejs');
const { ObjectID } = require('bson');
const { json } = require('body-parser');
var distance = require('gps-distance');
const passport = require('passport');



///google authentication 

require('./auth');
const urlencodedParser = bodyParser.urlencoded({ extended: false });
/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('index', { title: 'Express' });
});

MongoClient.connect(url, function (err, db) {
  if (err) throw err;
  dbCon = db.db("myresdb");     //there can be multiple dbs so from db we get mydb                                                            //we have stored the connection in this variable dbCon; and we can use it
  // db.close();

});

router.get('/googleauth', (req, res) => {
  res.send('<a href="/auth/google">Authenticate with google</a>');
})

router.get('/auth/google',
  passport.authenticate('google', {
    scope:
      ['email', 'profile']
  }
  ));
router.get("/auth/google/callback",
  //  console.log('hello'),/
  passport.authenticate('google', {
    successReturnToOrRedirect  : '/selectres1',
    failureRedirect: '/login',
  }));

//routes

router.get('/login1', (req, res) => {
  res.render('login1')
})
router.get('/register', function (req, res, next) {
  res.render('reg', { title: 'Express' });
});

router.get('/login', (req, res) => {
  res.render('login1');
})
router.post('/registersave', urlencodedParser,
  [
    check('first_name', "This name should be minimum 3 characters long")
      .exists()
      .isLength({ min: 3 }).notEmpty(),
    check('last_name', 'invalid name').notEmpty(),
    check('user_name', 'Dont leave user name empty').notEmpty(),
    check('user_password', 'Enter Specified Password').isLength({ min: 6 }).notEmpty(),
    check('email', "Email is not valid")
      .isEmail()
      .normalizeEmail().notEmpty(),
    check('contact_no', 'Enter only numbers and of length 10 for contact number').notEmpty().isNumeric().isLength(10),
  ],
  (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      const alert = errors.array();
      console.log(alert);
      res.render('reg', { alert })
    }
    else {
      var registerDetails =
      {
        'firstname': req.body.first_name,
        'lastname': req.body.last_name,
        'username': req.body.user_name,
        'userpassword': req.body.user_password,
        'confirmpassword': req.body.confirm_password,
        'email': req.body.email,
        'contactno': req.body.contact_no
      }
      console.log(registerDetails);
      async function registerusersave() {
        var details = await dbCon.collection('User').find({ email: registerDetails.email }).toArray();
        if (details.length == 0) {
          if (req.body.user_password == req.body.confirm_password) {
            var hashPassword = await bcrypt.hash(registerDetails.userpassword, 10);
            registerDetails.userpassword = hashPassword;
            var userregDetails = await dbCon.collection('User').insertOne(registerDetails);
            alert("You have successfully registered");
            res.render('index', { 'g': '' });
          }
          else {
            alert("Sorry,The entered passwords are not same");
          }
        }
        else {
          alert('email you have entered is already present');
        }
      }
      registerusersave();
    }
  })
var present = 0;
var overal = 0;
var ratingobj = {}
var result= ''
router.get('/rating/:result', async (req, res) => {
  result = req.params.result;
  ratingobj["restaurant"] = result;
  console.log(req.params);
  res.render('rating', { result});
})
router.get('/expm', (req, res) => {
  res.render('experience', {});
})
router.get('/serve', (req, res) => {
  res.render('Serving', {});
})
router.get('/menu', (req, res) => {
  res.render('ratemenu', {});
})
router.get('/restaurant', (req, res) => {
  res.render('raterestaurant', {});
})
router.get('/price', (req, res) => {
  res.render('rateprice', {});
})

var foodrating;
var serverating;
var menurating;
var restaurantrating;
var pricerating;
var summ = 0
router.post('/food', async (req, res) => {
  foodrating = req.body.rating;
  summ = summ + parseFloat(foodrating)
  ratingobj["foodrating"] = foodrating;
  console.log(foodrating);
  console.log(ratingobj);
})
router.post('/serving', (req, res) => {
  serverating = req.body.rating;
  summ = summ + parseFloat(serverating)
  console.log(serverating);
  ratingobj["serverating"] = serverating;
  console.log(ratingobj);
})
router.post('/menuitem', (req, res) => {
  menurating = req.body.rating;
  summ = summ + parseFloat(menurating)
  ratingobj["menurating"] = menurating;
  console.log(ratingobj);
})
router.post('/pricing', (req, res) => {
  pricerating = req.body.rating;
  summ = summ + parseFloat(pricerating)
  ratingobj["pricerating"] = pricerating;
  console.log(ratingobj);
})
router.post('/restaurant', async (req, res) => {
  restaurantrating = req.body.rating;
  summ = summ + parseFloat(restaurantrating)
  ratingobj["restaurantrating"] = restaurantrating;
  console.log(ratingobj);
  //summ =parseFloat(foodrating)+parseFloat(serverating)+parseFloat(menurating)+parseFloat(pricerating)+parseFloat(restaurantrating);
  console.log(summ, parseFloat(foodrating));
  console.log(result);
  ratingobj["overall"] = summ / 5;
  var pre = await dbCon.collection('rating').find({restaurant:result}).toArray();
  console.log(pre.overall,"overall");
  for(let val of pre)
  {
    console.log(pre.val)
  }
  if(pre.length!=0)
  {
     console.log("this is update",present);
     var findoverall = await dbCon.collection('rating').find({restaurant:result}).toArray();
     console.log(findoverall);
     const filter ={restaurant:result};
     const updateDoc = {
      $set: {
        overall: summ / 5
      }
      };
     var ratingstotal = await dbCon.collection('rating').updateOne(filter, updateDoc);
     res.render('selectres', {ratingstotal,ratings});
     console.log(ratingstotal);
  }
  else
  {
    console.log("this is insert",present);
  await dbCon.collection("rating").insertOne(ratingobj);
  var ratingstotal = await dbCon.collection('rating').find({}).toArray();
  res.render('selectres', {ratingstotal,ratings});
  console.log(present);
  }
})
  
router.get('/rating', (req, res) => {
  async function getrating() 
  {
    ratings = []
    restaurants=[]
    console.log("hiiiiiiiii");
    var sorted = await dbCon.collection('rating').aggregate(
      [
        { $sort : { overall : -1 } }
      ]).toArray(); 
    console.log(sorted);
    for(let i=0;i<sorted.length;i++)
    {
      ratings.push(sorted[i].overall)
      restaurants.push(sorted[i].restaurant)
    }
    console.log(ratings,restaurants)
    console.log(ratings.length);
    restaurants=[...new Set(restaurants)]
   res.render('selectres',{ratings,restaurants});
   console.log(ratings);
  }
  getrating();
})

/*
router.post('/loginvalidation', (req, res) => {
  var email_send = req.body.email_send;
  var password = req.body.password;
  // async function loginval() {
  //   var checkdet = await dbCon.collection('User').findOne({ 'email': email_send });
  //   if (checkdet == null) {
  //     req.session.auth = false;
  //     res.json({ msg: 'please register you dont have an account' });
  //     //res.render("reg", {});
  //   }
  //   else {
  //     var comparedet = await bcrypt.compare(req.body.password, checkdet.userpassword);
  //     console.log(comparedet);
  //     if (comparedet) {
  //       req.session.auth = true;
  //       console.log('incompare');
  //       res.render('selectres', { 'checkdet': checkdet });
  //       console.log("hello");
  //     }
  //     else {
  //       req.session.auth = false;
  //       res.json({ msg: "password you have entered is incorrect" });
  //       console.log('please sign in you dont have an account');
  //     }
  //   }
  // }
  // loginval();
})
*/
router.get('/Edit/:Id', (req, res) => {
  async function condition() {
    var id = req.params.Id;
    var Editdetails = await dbCon.collection('Table').findOne({ _id: ObjectID(id) });
    var Timeobj = new Array();
    var TableValues = await dbCon.collection('Table').find({ restaurent: Editdetails.restaurent, date: Editdetails.date }).toArray();
    console.log(TableValues);
    for (let i = 0; i < TableValues.length; i++) {
      {
        Timeobj.push(TableValues[i].time);
      }
    }
    var newtime = ["10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00", "21:00", "22:00", "23:00"];
    var remainingtime = new Array();
    var date = new Date().getHours();
    var tdydate = new Date().getDate();
    var k = parseInt(Editdetails.date.substring(8, 11));
    var v;
    for (let t = 0; t < newtime.length; t++) {
      console.log(newtime[t], typeof (newtime[t]))

      v = parseInt(newtime[t].substring(0, 2));
      if (Timeobj.includes(newtime[t])) {

      }
      else {
        if (k == tdydate) {
          if (v <= date) {
          }
          else {
            remainingtime.push(newtime[t])
          }
        }
        else {
          remainingtime.push(newtime[t])
        }
      }
    }
    res.render('Editusertable', { 'Editdetails': Editdetails, 'remainingtime': remainingtime });
  }
  condition();
})

router.get('/Editmydata/:Id', (req, res) => {

  async function condition() {
    var id = req.params.Id;
    var Editdetails = await dbCon.collection('Table').findOne({ _id: ObjectID(id) });
    var Timeobj = new Array();
    var TableValues = await dbCon.collection('Table').find({ restaurent: Editdetails.restaurent, date: Editdetails.date }).toArray();
    for (let i = 0; i < TableValues.length; i++) {
      {
        Timeobj.push(TableValues[i].time);
      }
    }
    var newtime = ["10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00", "21:00", "22:00", "23:00"];
    var remainingtime = new Array();
    var date = new Date().getHours();
    var tdydate = new Date().getDate();
    var k = parseInt(Editdetails.date.substring(8, 11));
    var v;
    for (let t = 0; t < newtime.length; t++) {
      console.log(newtime[t], typeof (newtime[t]))

      v = parseInt(newtime[t].substring(0, 2));
      if (Timeobj.includes(newtime[t])) {

      }
      else {
        if (k == tdydate) {
          if (v <= date) {

          }
          else {
            remainingtime.push(newtime[t])
          }
        }
        else {
          remainingtime.push(newtime[t])
        }
      }
    }
    res.render('editMydata', { 'Editdetails': Editdetails, 'remainingtime': remainingtime });
  }
  condition();
})

router.post('/loginsave', urlencodedParser, [
  check('email', "Email is not valid")
    .isEmail()
    .normalizeEmail(),
  check('password', 'Enter Specified Password').isLength({ min: 6 })
],
  (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      const alert = errors.array();
      res.render('login1', { alert })
    }
    else {
      async function check() {
        var registerDetails =
        {
          'email': req.body.email,
          'userpassword': req.body.password
        }
        var det = await dbCon.collection('User').find({}).toArray();
        var checkdet = await dbCon.collection('User').findOne({ 'email': registerDetails.email });
        if (checkdet == null) {
          req.session.auth = false;
          alert('please sign in you dont have an account');
          res.render("reg", {});
        }
        var comparedet = await bcrypt.compare(registerDetails.userpassword, checkdet.userpassword);
        if (comparedet) {
          req.session.auth = true;
          ratings={}
          res.render('selectres', { 'checkdet': checkdet ,'ratings':ratings});
        }
        else {
          req.session.auth = false;
          alert("please enter correct pasword");
        }
      }
      check();
    }
  })


router.get('/selectres1', (req, res) => {
  var ratings=[]
  var restaurants=[]
  res.render('selectres',{ratings,restaurants});
})
router.get('/Deletemydata/:id', (req, res) => {
  async function Delete() {
    try {
      var id = req.params.id;
      console.log(id);
      var DelTable = await dbCon.collection('Table').deleteOne({ _id: ObjectID(id) });
      console.log(DelTable);
      var userData = await dbCon.collection('Table').find({}).toArray();
      res.render('MyBookings', { 'userData': userData });
    }
    catch (error) {
      throw error;
    }
  }
  Delete();

})


router.post('/booktable1', (req, res) => {
  /* check('restaurent','please select any restaurant').isEmpty(),
   check('date','please select some date').isEmpty(),
 
 ] ,(req, res) => {
   const errors = validationResult(req)
   if (!errors.isEmpty()) {
     const alert = errors.array();
     console.log(alert);
    // res.render('selectres',{ alert ,checkdet});
   }
 
   else {
     */
  async function condition() {
    try {
      var resdet =
      {
        'restaurent': req.body.restaurent,
        'date': req.body.date
      }
      var Timeobj = new Array();
      var tableObj1 = {};
      var TableValues = await dbCon.collection('Table').find({ restaurent: resdet.restaurent, date: resdet.date }).toArray();
      console.log(TableValues.length)
      for (let i = 0; i < TableValues.length; i++) {
        {
          var partime = TableValues[i].time;
          Timeobj.push(TableValues[i].time);
          console.log(i);
          var tableObj = new Array();
          var Tablevalues_on_slot = await dbCon.collection('Table').find({ restaurent: resdet.restaurent, date: resdet.date, time: partime }).toArray();
          for (let tableno = 0; tableno < Tablevalues_on_slot.length; tableno++) {
            tableObj.push(Tablevalues_on_slot[tableno].Table_number);
            console.log(TableValues[i].time, Tablevalues_on_slot[tableno].Table_number)
            let uniquetableObj = [...new Set(tableObj)];
            tableObj1[TableValues[i].time] = uniquetableObj;
            console.log(Tablevalues_on_slot[tableno].Table_number, TableValues[i].time)
          }
          console.log(tableObj)
        }
      }
      let uniquetableObj = [...new Set(tableObj)];
      console.log(uniquetableObj);
      console.log(tableObj1)
      var newtime = ["10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00", "21:00", "22:00", "23:00"];
      var remainingtime = new Array();
      var date = new Date().getHours();
      var tdydate = new Date().getDate();
      var k = parseInt(resdet.date.substring(8, 11));
      var v;
      for (let t = 0; t < newtime.length; t++) {
        v = parseInt(newtime[t].substring(0, 2));
        if (Timeobj.includes(newtime[t])) {
          console.log(tableObj1[newtime[t]].length)
          if (tableObj1[newtime[t]].length == 10) {

          }
          else {
            remainingtime.push(newtime[t])
          }

        }
        else {
          if (k == tdydate) {
            if (v <= date) {

            }
            else {
              remainingtime.push(newtime[t])
            }
          }
          else {
            remainingtime.push(newtime[t])
          }
        }
      }

      res.render('bookTable1', { 'resdet': resdet, 'remainingtime': remainingtime });
    }
    catch (error) {
      console.log(error)
    }

  }

  condition();


})




//Admin Login
router.get('/admin', (req, res) => {
  res.render('AdminLogin', { 'hello': '' });
})
//Admin Authentication
router.post('/adminform', (req, res) => {
  var pipeline = [
    {
      '$group': {
        '_id': '$restaurent',
        'Count': {
          '$sum': 1
        }
      }
    }
  ];
  async function usertable() {
    var userData1 = await dbCon.collection('Admin').find({ email: req.body.email, password: req.body.password }).toArray();
    console.log(userData1);
    if (userData1.length != 0) {
      var RestaurentDetails = await dbCon.collection('Table').aggregate(pipeline).toArray();
      var data = []
      var labels = []
      for (var x of RestaurentDetails) {
        data.push(x.Count)
        labels.push(x._id)
      }
      res.render('userTableNew', { 'RestaurentDetails': RestaurentDetails, labels: labels, data: data });
    }
    else {
      alert("please enter correct Details");
      res.render('AdminLogin', {});
    }
  }
  usertable();
}
)



router.get('/Restaurent/:name', (req, res) => {
  async function resdet() {
    var resdetails = await dbCon.collection('Table').find({ restaurent: req.params.name }).toArray();
    res.render('RestaurentBooked', { resDetails: resdetails });
  }
  resdet();
})


//Email Validation using AJAX
router.post('/emailform', (req, res) => {
  async function adminemail() {
    var email_in = req.body.email;
    var regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email_in)
    if (regex) {
      res.json(
        {
          msg: ""
        })
    }
    else if (email_in.length == 0) {
      res.json(
        {
          msg: "email column should not be empty"
        }
      )
    }
    else {
      res.json(
        {
          msg: "please enter valid email",
        })
    }
  }
  adminemail();
})


//Password Validation using Ajax
router.post('/passform', (req, res) => {
  async function adminpassword() {
    var password = req.body.password;
    console.log(password);
    var regex1 = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/.test(password);
    //  var Emaildet = await dbCon.collection('Admin').find({ email : email_in });
    if (regex1) {
      res.json(
        {
          msg: ""
        })
    }
    else if (password.length == 0) {
      res.json(
        {
          msg: "password column should not be empty"
        }
      )
    }
    else {
      res.json(
        {
          msg: "please enter valid password",
        })
    }
  }
  adminpassword();
})


router.get('/Mybookings/:Email', (req, res) => {
  var emailcheck = req.params.Email;
  var id = req.params.ID;
  console.log(emailcheck, id);
  async function Mytable() {
    var userData = await dbCon.collection('Table').find({ email: emailcheck },).toArray();
    console.log(userData);
    res.render('MyBookings', { 'userData': userData });
  }
  Mytable();
})



router.post('/booktableform1/:resname/:date', (req, res) => {
  async function condition() {
    try {
      var resdet =
      {
        'restaurent': req.params.resname,
        'date': req.params.date,
        'time': req.body.time
      }
      var totalDet =
      {
        'username': req.body.username,
        'email': req.body.email,
        'contact': req.body.contact,
        'count': req.body.count,
        'date': req.params.date,
        'time': req.body.time,
        'restaurent': req.params.resname
      }
      var Tableobj = new Array();
      var TableValues = await dbCon.collection('Table').find({ restaurent: resdet.restaurent, date: resdet.date, time: resdet.time }).toArray();
      for (let i = 0; i < TableValues.length; i++) {
        {
          Tableobj.push(TableValues[i].Table_number);
        }
      }
      var Table_num = ["TB01", "TB02", "TB03", "TB04", "TB05", "TB06", "TB07", "TB08", "TB09", "TB10"];
      var remainingTable = new Array();
      for (let t = 0; t < Table_num.length; t++) {
        if (Tableobj.includes(Table_num[t])) {

        }
        else {
          remainingTable.push(Table_num[t])
        }
      }
      res.render('Tablefinal', { 'alert': alert, 'totalDet': totalDet, 'resdet': resdet, 'remainingTable': remainingTable });
    }
    catch (error) {
      throw error;
    }
  }

  condition();
}
)
router.post('/booktableform12/:res/:date/:time/:name/:email/:contact/:count', (req, res) => {
  async function entire() {
    var entireTableDetails =
    {
      username: req.params.name,
      email: req.params.email,
      contact: req.params.contact,
      count: req.params.count,
      date: req.params.date,
      time: req.params.time,
      Table_number: req.body.Table_number,
      restaurent: req.params.res,
    }
    console.log(entireTableDetails.email)
    var userDetails = await dbCon.collection('User').findOne({ "email": entireTableDetails.email });
    if (userDetails != null) {
      console.log(entireTableDetails.restaurent, entireTableDetails.date, entireTableDetails.time, entireTableDetails.Table_number)
      var usercheckDetails = await dbCon.collection('Table').findOne({ restaurent: entireTableDetails.restaurent, date: entireTableDetails.date, time: entireTableDetails.time, Table_number: entireTableDetails.Table_number });
      console.log(usercheckDetails, 'huu');
      if (usercheckDetails == null) {
        var bookedDetails = await dbCon.collection('Table').insertOne(entireTableDetails);
      }
      else {
        var bookedDetails = await dbCon.collection('Table').updateOne({ $set: entireTableDetails });
      }
      async function Email() {
        let transporter = nodemailer.createTransport({
          host: 'smtp.gmail.com',
          port: 587,
          secure: false, // true for 465, false for other ports
          requireTLS: true,
          auth: {
            user: 'manojkumarankam0405@gmail.com', // generated ethereal user
            pass: 'advmani@2999', // generated ethereal password
          },
        });
        const sendMessage = {
          from: 'manojkumarankam0405@gmail.com', // sender address
          to: entireTableDetails.email, // list of receivers
          subject: "Enjoy the Meal",// Subject line
          text: "Welcome to BookDine \n Thank You for Booking! \n  Name : " + entireTableDetails.username + "\nRetaurant : " + entireTableDetails.restaurent + "\nDate : " + entireTableDetails.date + "\ntime : " + entireTableDetails.time + "\nTable_Number : " + entireTableDetails.Table_number + "\n Thanks for Booking", // plain text body// html body
        }
        // send mail with defined transport object
        const info = await transporter.sendMail(sendMessage);
        // Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>

        // Preview only available when sending through an Ethereal account
        console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
        // Preview URL: https://ethereal.email/message/WaQKMgKddxQDoou..
      }

      Email();
      res.render("booked", { "bookedDetails": entireTableDetails, 'usercheckDetails': usercheckDetails });
    }
    else {
      console.log('please login and try again');
      alert("Iam sorry please Login first");
      res.redirect('/login1');
    }

  }
  entire();
})


/*
else {
async function book() {
  var tableDetails =
  {
    'username': req.body.username,
    'email': req.body.email,
    'contact': req.body.contact,
    'count': req.body.count,
    'date': req.params.date,
    'time': req.body.time,
    'restaurent': req.params.resname
  }
  var userDetails = await dbCon.collection('User').findOne({ "email": tableDetails.email });
  console.log(userDetails)
  if (userDetails != null) {
    res.render('bookTable1',userDetails)
    var bookedDetails = await dbCon.collection('Table').insertOne(tableDetails);
    console.log(bookedDetails);
    async function Email() {
      console.log('hello');
 
      let transporter = nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        secure: false, // true for 465, false for other ports
        requireTLS: true,
        auth: {
          user: 'manojkumarankam0405@gmail.com', // generated ethereal user
          pass: 'advmani@2999', // generated ethereal password
        },
      });
      const sendMessage = {
        from: 'manojkumarankam0405@gmail.com', // sender address
        to: tableDetails.email, // list of receivers
        subject: "Enjoy the Meal",// Subject line
        text: "Name : " + tableDetails.username + "\nRetaurant : " + tableDetails.restaurent + "\nDate : " + tableDetails.date + "\ntime : " + tableDetails.time + "\nThanks for Booking", // plain text body// html body
      }
      // send mail with defined transport object
      const info = await transporter.sendMail(sendMessage);
 
      console.log("Message sent: %s", info.messageId);
      // Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>
 
      // Preview only available when sending through an Ethereal account
      console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
      // Preview URL: https://ethereal.email/message/WaQKMgKddxQDoou..
    }
    Email();
  }
  else {
    console.log('please login and try again');
  }
  res.render("booked", { "bookedDetails": tableDetails });
}
book();
}
})*/

router.post('/distancecal', async (req, res) => {
  var lat = 17.4367092
  var lon = 78.3648314;
  var rests = await dbCon.collection('location').find({}, { projection: { _id: 0, restaurant: 1, Latitude: 1, Longitude: 1 } }).toArray()
  var selectedRests = []
  for (let x of rests) {
    var result = distance(parseFloat(lat), parseFloat(lon), x.Latitude, x.Longitude);
    const val = req.body.distance.substring(0, 2);
    if (result <= val) {
      selectedRests.push(x.restaurant)
    }
  }
  res.json([{
    restaurants: selectedRests
  }
  ])
})
router.get('/map', (req, res) => {
  res.render('Map', {});
})

router.get('/help', (req, res) => {
    res.render('helpdesk');
})
module.exports = router;
