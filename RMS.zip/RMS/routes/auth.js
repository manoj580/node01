const passport = require('passport');
const GoogleStrategy = require( 'passport-google-oauth2' ).Strategy;
passport.use(new GoogleStrategy({
    clientID:     '140418774757-rt5gqaukjj7r808u2asq6gipejdosaat.apps.googleusercontent.com',
    clientSecret: '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',
    callbackURL: "http://localhost:3000/auth/google/callback",
    //userProfileURL:"http://www.googleapis.com/oauth2/v3/userinfo",
    passReqToCallback   : true
  },
  function(request, accessToken, refreshToken, profile, done) { 
      console.log(profile); // when u successfully login
      request.session.auth=true
   // User.findOrCreate({ googleId: profile.id }, function (err, user) {  // create a user if he s new and find if he is already their 
      return done(null, profile);
    
  }
));
passport.serializeUser(function(user,done)
{
    done(null,user);
})

passport.deserializeUser(function(user,done)
{
    done(null,user);
})